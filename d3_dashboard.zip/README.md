# d3_dashboard
css and js files added

Added:
- Converted x axis to required scale of twice of previous and align properly
- Added 'K' for thousand values
- Using original data to run the sample

Later:
Additional feature : Change to colors to make it easy to read for color blind people.

Added: 
- Data is present only from 1950. Before that we have data at every 10 years from 1900 onwards.
- Some Transition fix. 
